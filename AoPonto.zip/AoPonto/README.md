Ao Ponto



Descrição

A Ao Ponto é uma aplicação Android desenvolvida em Kotlin para ajudar a organizar as tarefas de limpeza de uma casa.O utilizador pode registar as características da casa, gerir tarefas e criar planos de limpeza de acordo com o tempo que tem disponível.A aplicação funciona offline e guarda os dados no dispositivo.



Funcionalidades

Configuração da casa, incluindo divisões, adultos, crianças e animais.

Criação, edição e eliminação de tarefas de limpeza.

Catálogo inicial com tarefas que podem ser ativadas ou desativadas.

Organização das tarefas por prioridade e frequência.

Criação de planos de limpeza de 15, 30, 45 ou 60 minutos.

Registo das tarefas concluídas.

Consulta do histórico de limpezas.

Visualização do progresso diário através de um bordado inspirado no Bordado de Castelo Branco.

Guias de limpeza com instruções e avisos de segurança.

Recomendações de tarefas de acordo com as características da casa.

Notificações para tarefas prioritárias.



Tecnologias utilizadas

\- Kotlin

\- Android Studio

\- Jetpack Compose, para a interface

\- ViewModel, para gerir o estado e a lógica

\- Room, para guardar os dados

\- SharedPreferences, para guardar as configurações

\- WorkManager, para as notificações periódicas



Armazenamento de dados

A aplicação utiliza Room para guardar as tarefas, os registos de realização e os restantes dados necessários. Cada tarefa possui um identificador, nome, divisão, duração, frequência, prioridade e informações sobre a sua realização. As configurações da casa são guardadas através de SharedPreferences. Os dados mantêm-se guardados depois de fechar a aplicação.



Organização do projeto



O código está dividido em diferentes partes:

data: base de dados Room, entidades e DAOs.

viewmodel:lógica das tarefas, planos, recomendações e notificações.

ui: ecrãs desenvolvidos com Jetpack Compose.

MainActivity: navegação principal da aplicação.

SobreActivity: informação sobre a aplicação.



Como executar


Android Studio
Abrir o projeto no Android Studio. Aguardar a sincronização do Gradle. Selecionar um emulador ou dispositivo Android compatível.Executar a aplicação através do botão Run.

O projeto foi desenvolvido para funcionar num ambiente Android compatível com a API 29 ou superior.

APK
Instalar o ficheiro AoPonto.apk num dispositivo Android compatível abrir a aplicação e fazer a configuração inicial da casa e começar a utilizar as funcionalidades.


Como testar



Na primeira utilização, configurar a casa e selecionar as divisões existentes. Depois, testar a criação, edição e eliminação de tarefas. É também possível concluir tarefas e verificar os registos no histórico.

Para testar os planos, selecionar um tempo disponível e criar um plano de limpeza. As tarefas sugeridas devem respeitar o tempo escolhido.

Para verificar o armazenamento, criar uma tarefa, fechar a aplicação e voltar a abri-la. A tarefa deverá continuar guardada. As funcionalidades principais podem ser utilizadas sem ligação à Internet.



Decisões de implementação



Foi utilizado Jetpack Compose para criar a interface sem recorrer a layouts XML. A lógica foi separada dos ecrãs através de ViewModels, e o Room foi escolhido para guardar os registos localmente.As tarefas são organizadas tendo em conta a frequência, o tempo desde a última realização e as características da casa. O progresso diário é apresentado através de imagens inspiradas no Bordado de Castelo Branco.



Dificuldades



Uma das principais dificuldades foi organizar a ligação entre a interface, os ViewModels e a base de dados Room também foi necessário trabalhar a atualização das tarefas concluídas, o histórico e a criação de planos de acordo com o tempo disponível.



Funcionalidades adicionais



Foram implementadas funcionalidades para além da gestão básica de registos, como pesquisa e filtros, planos automáticos, recomendações, notificações, histórico com gráficos e progresso visual.



Utilização de inteligência artificial



Durante o desenvolvimento foi utilizado o ChatGPT, da OpenAI, como ferramenta de apoio para esclarecer dúvidas sobre Kotlin, Jetpack Compose, Room e WorkManager, bem como para ajudar na revisão e organização de partes do código.



O código foi integrado e testado no Android Studio no âmbito do desenvolvimento do projeto.

